//package com.movie.recommendation;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//public class MovieRecommendationSystemTests {
//
//    @Test
//    void contextLoads() {
//    }
//
//}
