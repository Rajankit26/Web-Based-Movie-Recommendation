package com.movie.recommendation.util;

public class RecommendationAlgorithm {

    public static void main(String[] args) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
